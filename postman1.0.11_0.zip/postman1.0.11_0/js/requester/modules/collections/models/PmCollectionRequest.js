var PmCollectionRequest = Backbone.Model.extend({
    defaults: function() {
        return {
        };
    }
});