var ResponseBodyRawViewer = Backbone.View.extend({
    initialize: function() {

    }
});